﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace BTVN
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            string Stt = txtStt.Text;
            string Hoten = txtHoten.Text;
            string Lophoc = txtLophoc.Text;

            ListViewItem item = new ListViewItem(Stt);
            item.SubItems.Add(Hoten);
            item.SubItems.Add(Lophoc);

            lvHocSinh.Items.Add(item);

            txtStt.Clear();
            txtHoten.Clear();
            txtLophoc.Clear();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            ListViewItem selectedItem = lvHocSinh.SelectedItems[0];
            lvHocSinh.Items.Remove(selectedItem);
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            ListViewItem selectedItem = lvHocSinh.SelectedItems[0];

            selectedItem.Text = txtStt.Text;
            selectedItem.SubItems[1].Text = txtHoten.Text;
            selectedItem.SubItems[2].Text = txtLophoc.Text;

            txtStt.Clear();
            txtHoten.Clear();
            txtLophoc.Clear();
        }
    }
}
